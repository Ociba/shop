<?php

namespace App\Http\Livewire\Clients;

use Livewire\Component;

class EditMyAccomodation extends Component
{
    public function render()
    {
        return view('livewire.clients.edit-my-accomodation');
    }
}
