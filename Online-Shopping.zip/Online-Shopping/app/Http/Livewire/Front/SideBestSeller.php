<?php

namespace App\Http\Livewire\Front;

use Livewire\Component;

class SideBestSeller extends Component
{
    public function render()
    {
        return view('livewire.front.side-best-seller');
    }
}
