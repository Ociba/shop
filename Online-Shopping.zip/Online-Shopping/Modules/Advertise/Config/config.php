<?php

return [
    'name' => 'Advertise',
];
