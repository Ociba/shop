<?php

return [
    'name' => 'AgricultureEquipments',
];
