<?php

return [
    'name' => 'Payments',
];
