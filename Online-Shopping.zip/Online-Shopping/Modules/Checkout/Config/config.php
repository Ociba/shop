<?php

return [
    'name' => 'Checkout',
];
