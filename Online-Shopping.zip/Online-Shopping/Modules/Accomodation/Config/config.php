<?php

return [
    'name' => 'Accomodation',
];
