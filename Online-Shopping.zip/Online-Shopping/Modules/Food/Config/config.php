<?php

return [
    'name' => 'Food',
];
