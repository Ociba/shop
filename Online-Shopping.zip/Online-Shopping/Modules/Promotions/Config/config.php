<?php

return [
    'name' => 'Promotions'
];
