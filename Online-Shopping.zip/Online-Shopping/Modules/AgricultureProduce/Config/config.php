<?php

return [
    'name' => 'AgricultureProduce',
];
