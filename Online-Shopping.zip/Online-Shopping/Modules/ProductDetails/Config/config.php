<?php

return [
    'name' => 'ProductDetails',
];
