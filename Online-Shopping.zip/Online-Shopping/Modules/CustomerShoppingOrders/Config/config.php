<?php

return [
    'name' => 'CustomerShoppingOrders',
];
