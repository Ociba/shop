<?php

return [
    'name' => 'ErrorPage',
];
