<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProductDetails\\Providers\\ProductDetailsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProductDetails\\Providers\\ProductDetailsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);