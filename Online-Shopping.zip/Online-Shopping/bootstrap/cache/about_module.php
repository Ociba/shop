<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\About\\Providers\\AboutServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\About\\Providers\\AboutServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);