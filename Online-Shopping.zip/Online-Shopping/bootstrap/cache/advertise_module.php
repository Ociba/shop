<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Advertise\\Providers\\AdvertiseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Advertise\\Providers\\AdvertiseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);