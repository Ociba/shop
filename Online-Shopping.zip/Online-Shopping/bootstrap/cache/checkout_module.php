<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Checkout\\Providers\\CheckoutServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Checkout\\Providers\\CheckoutServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);