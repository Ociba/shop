<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Requests\\Providers\\RequestsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Requests\\Providers\\RequestsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);