<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Shop\\Providers\\ShopServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Shop\\Providers\\ShopServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);