<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Promotions\\Providers\\PromotionsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Promotions\\Providers\\PromotionsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);