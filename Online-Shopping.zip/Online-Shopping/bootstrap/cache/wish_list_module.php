<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\WishList\\Providers\\WishListServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\WishList\\Providers\\WishListServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);