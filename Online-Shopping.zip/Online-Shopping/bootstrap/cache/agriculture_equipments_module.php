<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AgricultureEquipments\\Providers\\AgricultureEquipmentsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AgricultureEquipments\\Providers\\AgricultureEquipmentsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);