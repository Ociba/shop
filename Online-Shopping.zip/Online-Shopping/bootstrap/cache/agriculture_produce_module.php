<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AgricultureProduce\\Providers\\AgricultureProduceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AgricultureProduce\\Providers\\AgricultureProduceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);