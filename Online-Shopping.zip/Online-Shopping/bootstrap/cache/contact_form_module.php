<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ContactForm\\Providers\\ContactFormServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ContactForm\\Providers\\ContactFormServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);