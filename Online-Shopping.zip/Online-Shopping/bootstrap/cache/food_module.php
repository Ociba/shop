<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Food\\Providers\\FoodServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Food\\Providers\\FoodServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);